Files:
crc_checksum.py
and hamming_code.py

Commands to be used :
1.python3 crc_checksum.py filename > output1.txt
2.python3 hamming_code.py > output2.txt

Then look at the files output1.txt and output2.txt to check the answer
Note: I had used chr(encoded_byte_to_integer) for the character decoding and the characters were not being
printed on the terminal but when directed to the files they were printed.

Things to make sure:
1. For 2 make sure that there is a file named "input.txt" in the same directory as the python file
2. For the first file make sure that reading permissions are given to the file given as input

Version of python used :
python 3.7.3
