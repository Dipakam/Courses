R -f facet.v
eog facet.jpg
