insertAt :: Char -> [Char] -> Int -> [Char]
insertAt a xs 0 = error "Insertion should be at index greater than zero"
insertAt a [] 1 = [a]
insertAt a xs 1 = a : xs
insertAt a xs b = (head xs ) : (insertAt a (tail xs) (b-1))
