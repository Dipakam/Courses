insert.hs contains solution to question 1 :
Steps to use -- 1. echo "insertAt '<char>' \"<string>\" <index> " | ghci insert.hs
		2. index has to be a number greater than 0 , To insert at the first position in string index = 1
		3. if index is greater than the length of the string then the program simply inserts at the end of the string

incc.hs contais solution to question 2 :
Steps to use -- 1. echo "incc [<list of integers>] (<starting index>,<ending index>) " | ghci incc.hs
		2. indexing starts at 1 , also starting index should be smaller than ending index

comb.hs sontains solution to question 3 :
Steps to use -- 1. echo "comb <length> \"<String>\" " | ghci comb.hs
		2. length should be non negative 

