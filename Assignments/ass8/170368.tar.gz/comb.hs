comb :: Int -> [Char] -> [[Char]]
before ::  Char -> [Char] -> [Char]
before x y
	| x == (head y) = []
	| otherwise = (head y) : (before x (tail y))
comb 0 a = [[]]
comb x [] = []
comb x a = [y ++ [z] | z <- a,y <- (comb (x-1) (before z a)),(not (elem z y))]
