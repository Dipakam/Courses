main = putStrLn "What's your name?" >> getLine >>= putStrLn.("Hi " ++)
