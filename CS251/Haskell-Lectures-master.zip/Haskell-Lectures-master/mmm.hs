f :: Int -> Maybe Int
f n = Just (n+1)